package ch.epfl.cs107.play.game.arpg.actor.puzzle;

public interface Actionable {

	/**
	 * This method is used to change the state of an entity
	 */
	void activeEntity();
	
}
