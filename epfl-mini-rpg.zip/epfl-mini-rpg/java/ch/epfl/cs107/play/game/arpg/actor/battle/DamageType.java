package ch.epfl.cs107.play.game.arpg.actor.battle;

public enum DamageType {
	FIRE,
	PHYSICAL,
	MAGICAL
}
