package ch.epfl.cs107.play.game.arpg.actor.entity;

public interface SoundEntity {

	/**
	 * This method is used to reactivate a sound
	 */
    void reactivateSounds();

}
