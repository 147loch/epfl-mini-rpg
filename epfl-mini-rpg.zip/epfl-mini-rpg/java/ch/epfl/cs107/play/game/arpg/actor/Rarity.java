package ch.epfl.cs107.play.game.arpg.actor;

public interface Rarity {
	double COMMON = 1.0/2.0;
	double UNCOMMON = 1.0/3.0;
	double RARE = 1.0/5.0;
	double LEGENDARY = 1.0/10.0;
}
