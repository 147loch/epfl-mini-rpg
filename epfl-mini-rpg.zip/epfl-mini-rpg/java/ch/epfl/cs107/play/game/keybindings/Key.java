package ch.epfl.cs107.play.game.keybindings;

public interface Key {

    int getCode();

}
