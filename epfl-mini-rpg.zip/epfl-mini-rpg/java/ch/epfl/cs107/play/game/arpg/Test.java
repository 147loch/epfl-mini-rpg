package ch.epfl.cs107.play.game.arpg;

public interface Test {
    boolean MODE = false; // we did not add public final static as it is redundant for interface constants
}
